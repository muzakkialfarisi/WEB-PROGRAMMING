<div id="center" class="contentcetner">
    <div class="RadAjaxPanel" id="ctl00_ctl00_centerListPanel" style="display: block;">
	    <div id="centerList">        
            <div id="contentCenter_contentHTML">
                <div style="font-size: 1.4em;">
                    <b>Mekanisme Penerbitan NISN</b>
                </div> <br> <br>
                <table border="0" cellpadding="0" cellspacing="10">
                    <tbody>
                        <tr>
                            <td><b>1. Kementerian Pendidikan dan Kebudayaan</b><br>
                            <img src="/images/mekanisme-nisn-1.jpg"></td>
                        </tr>
                        <tr><td>&nbsp;</td></tr>
                        <tr>
                            <td><b>2. Kementerian Agama (Pendidikan Islam)</b><br>
                            <img src="/images/mekanisme-nisn-2.jpg"></td>
                        </tr>
                        <tr><td>&nbsp;</td></tr>
                        <tr>
                            <td><b>3. Kementerian Agama Bimbingan Masyarakat Kristen Dan Katolik</b><br>
                            <img src="/images/mekanisme-nisn-3.jpg"></td>
                        </tr>
                        <tr>
                            <td><img src="/images/mekanisme-ket-1.jpg"></td>
                        </tr>
                        <tr><td>&nbsp;</td></tr>
                        <tr>
                            <td colspan="2"><b>4. Lulusan SMA/SMK/MA yang Belum Memiliki NISN</b><br>
                            <img src="/images/mekanisme-nisn-4.jpg"></td>
                        </tr>
                        <tr>
                            <td><img src="/images/mekanisme-ket-2.jpg"></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>