<div id="center" class="contentcetner">
    <div class="RadAjaxPanel" id="ctl00_ctl00_centerListPanel" style="display: block;">
	    <div id="centerList">        
            <div id="contentCenter_contentHTML" >
                <span class="font-weight-bolder">Kontak Kami</span>
                <div>  <br>  
                    <b>Layanan Terpadu</b> <br>  
                    Gedung C Lantai 1<br>  
                    Komplek Kemdikbud<br>   
                    Senayan, Jakarta 10270 <br>  
                    Call Center : 177 <br>
                    Telp : (021) 5703303 <br> 
                    Fax : (021) 5733125 <br>
                    SMS : 0811976929<br>  
                    Email: <a href="mailto:pengaduan@kemdikbud.go.id">pengaduan@kemdikbud.go.id</a>  
                </div>
            </div>
        </div>
    </div>
</div>